// Olatem Global - Main JS

function handleEligibility(e) {
  e.preventDefault();
  const form = document.getElementById('eligibilityForm');
  const success = document.getElementById('formSuccess');
  if (!form || !success) return false;

  // Build WhatsApp message with form data
  const data = new FormData(form);
  let msg = 'Hello Olatem Global! I submitted the Free Eligibility Assessment:%0A%0A';
  msg += '1. Full Name: ' + (data.get('fullName') || '') + '%0A';
  msg += '2. Country: ' + (data.get('country') || '') + '%0A';
  msg += '3. Age: ' + (data.get('age') || '') + '%0A';
  msg += '4. Preferred Level: ' + (data.get('level') || '') + '%0A';
  msg += '5. Highest Qualification: ' + (data.get('qualification') || '') + '%0A';
  msg += '6. Graduation Year: ' + (data.get('gradYear') || '') + '%0A';
  msg += '7. Grades/GPA: ' + (data.get('grades') || '') + '%0A';
  msg += '8. Preferred Programme: ' + (data.get('programme') || '') + '%0A';
  msg += '9. English: ' + (data.get('english') || '') + '%0A';
  msg += '10. Passport: ' + (data.get('passport') || '') + '%0A';
  msg += '11. Preferred Intake: ' + (data.get('intake') || '') + '%0A';
  msg += '12. WhatsApp: ' + (data.get('whatsapp') || '') + '%0A';
  msg += '%0APlease assess my eligibility. Thank you!';

  // Show success and open WhatsApp
  form.style.display = 'none';
  success.classList.add('show');

  // Open WhatsApp with prefilled message
  const waUrl = 'https://wa.me/37062963913?text=' + msg;
  window.open(waUrl, '_blank');

  return false;
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// Close mobile menu on link click
document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    document.querySelector('.nav-links')?.classList.remove('open');
  });
});